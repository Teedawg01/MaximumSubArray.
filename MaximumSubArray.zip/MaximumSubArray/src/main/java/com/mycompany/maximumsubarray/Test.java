/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.maximumsubarray;




/**
 *
 * @author tudea
 */

/*
Input: nums = [-2,1,-3,4,-1,2,1,-5,4]
Output: 6
Explanation: The subarray [4,-1,2,1] has the largest sum 6.
Example 2:

Input: nums = [1]
Output: 1
Explanation: The subarray [1] has the largest sum 1.
Example 3:

Input: nums = [5,4,-1,7,8]
*/

public class Test {

    public static void main(String[] args) {
        
        int[] num1 = {-2,1,-3,4,-1,2,1,-5,4};
        
        int[] num2 = {1};
        
        int[] num3 = {5,4,-1,7,8};
        
        int[] num4 = {};
        
        MaximumSubArray test = new MaximumSubArray();
        test.SubArray(num1);
        System.out.println("");
        
        System.out.println("Example 2 ");
        test.SubArray(num2);
        System.out.println("");
        
         System.out.println("Example 3 ");
        test.SubArray(num3);
         System.out.println("");
         
         
         System.out.println("Example 4 ");
        test.SubArray(num4);
         
       
    }
}
